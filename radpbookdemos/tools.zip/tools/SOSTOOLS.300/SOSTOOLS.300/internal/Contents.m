% SOSTOOLS -- Sum of Squares Toolbox, internal files
% Version 3.00 
% 1st July 2013.