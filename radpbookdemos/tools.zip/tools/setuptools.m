run .\cvx-w64\cvx\cvx_startup.m
run .\SDPT3-4.0\SDPT3-4.0\startup.m
run .\SOSTOOLS.300\SOSTOOLS.300\addsostools.m